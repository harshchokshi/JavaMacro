package demo;
import java.awt.GridLayout;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Iterator;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
public class JavaMacro {
   
   
   public static void main(String[] args) {
	   String value1 = null;
	   String value2 = null;
	   String value3 = null;
	   JTextField field1 = new JTextField();
	   JTextField field2 = new JTextField();
	   JTextField field3 = new JTextField();
	   JTextField field4 = new JTextField();
	   JTextField field5 = new JTextField();
	   Object[] message = {
	       "Enter file path like C:\\\\myfolder\\\\abc.xls", field1,
	       "Enter row number from where testcase start", field2,
	       "Enter the ID like Test_Case_ID_", field3,
	     
	   };
	   int option = JOptionPane.showConfirmDialog(null, message, "Enter all your values", JOptionPane.OK_CANCEL_OPTION);
	  
	   if (option == JOptionPane.OK_OPTION)
	   {
	       value1 = field1.getText();
	       value2 = field2.getText();
	       value3 = field3.getText();
	    
	   }
	   
	   readXLSFile(value1);
	   int i = Integer.parseInt(value2);
	   readXLSFileWithBlankCells(value1, i, value3 );
	   
   }
   
	public static void readXLSFile(String EXCEL_FILE) {
		try {
			InputStream ExcelFileToRead = new FileInputStream(EXCEL_FILE);
			HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);

			HSSFSheet sheet = wb.getSheetAt(0);
			HSSFRow row;
			HSSFCell cell;

			Iterator rows = sheet.rowIterator();

			while (rows.hasNext()) {
				row = (HSSFRow) rows.next();
				Iterator cells = row.cellIterator();

				while (cells.hasNext()) {
					cell = (HSSFCell) cells.next();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void readXLSFileWithBlankCells(String EXCEL_FILE, int userRowNum, String testID) {
		boolean success = false;
		try {
			
			InputStream ExcelFileToRead = new FileInputStream(EXCEL_FILE);
			HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);

			HSSFSheet sheet = wb.getSheetAt(0);
			HSSFRow row;
			HSSFCell cell;
			
			Iterator rows = sheet.rowIterator();
			
			int counter = 1;
			userRowNum = userRowNum - 1;
			while (rows.hasNext()) {
				row = (HSSFRow) rows.next();
				
				int srno = 0;
				
					for (int i=0; (row.getRowNum()>=userRowNum&&i<row.getLastCellNum()); i++)
					{ 
					  cell = row.getCell(i, Row.CREATE_NULL_AS_BLANK);
				      
					  srno = i;
					  
						if (srno==1) {
						
							if (cell.getCellType() != cell.CELL_TYPE_BLANK) {
								row.getCell(srno-1).setCellValue(testID+counter);
								counter = counter+1; 
								success = true;
						    }
							
						}
				    	 
					}
					
				}

	        
	        FileOutputStream fileOut = new FileOutputStream("existing-spreadsheet.xls");
	        
	        if (success == true) {
	        	 System.out.println("Success.");
	        	 System.out.println("Refresh the project folder and open file: existing-spreadsheet.xls");
	        }
	        else {
	        	System.out.println("Fail to create magic.");
	        }
		
	        wb.write(fileOut);
	        fileOut.close();
	        wb.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		


	}
	

}